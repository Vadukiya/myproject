
<!DOCTYPE html>
<html>
<head>
<title>Jay weds Jay Dhrol</title>
<meta name="description" content="Jay Weds Jayshree Dhrol location, Jay Jayshree wedding Date schedule">
<meta name="keywords" content="Jay weds Jayshree, Jay Jayshree Wedding date location and schedule Dhrol.">
<meta name="robots" content="No index,No follow">
<!--css-->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style-2.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
<link href="dngview007/css/dngview/dngview.css" rel="stylesheet" type="text/css" media="all" />
<!--css-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="Tushar Weds Riti." />
<meta name="description" content="Tushar Weds Riti." />

	<link rel="shortcut icon" href="images/ico/apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">


<!--js-->
<!--webfonts-->

<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
<!--webfonts-->

 

</head>
<body>
	<!--header-->
	<div class="header" id="home">
			<?php include('include/header.php');?>
	</div>
	<!--header-->
	<!--banner-->
	 <div class="banner-section">
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides" id="slider">
					<li style="position:relative;">
					  <img src="images/banner-1.jpg" alt="">
					 <div class="announcement-wrapper">
                <!--<div class="announcement">
                    <span class="married-text">
                        <span class="wow fadeInUp" data-wow-delay="0.05s" style="visibility: visible; animation-delay: 0.05s; animation-name: fadeInUp;">W</span>
                        <span class="wow fadeInUp" data-wow-delay="0.10s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.15s" style="visibility: visible; animation-delay: 0.15s; animation-name: fadeInUp;">'</span>
                        <span class="wow fadeInUp" data-wow-delay="0.20s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.25s" style="visibility: visible; animation-delay: 0.25s; animation-name: fadeInUp;">e</span>
                        <span>&nbsp;</span>
                        <span class="wow fadeInUp" data-wow-delay="0.30s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">g</span>
                        <span class="wow fadeInUp" data-wow-delay="0.35s" style="visibility: visible; animation-delay: 0.35s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.40s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">t</span>
                        <span class="wow fadeInUp" data-wow-delay="0.45s" style="visibility: visible; animation-delay: 0.45s; animation-name: fadeInUp;">i</span>
                        <span class="wow fadeInUp" data-wow-delay="0.50s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">n</span>
                        <span class="wow fadeInUp" data-wow-delay="0.55s" style="visibility: visible; animation-delay: 0.55s; animation-name: fadeInUp;">g</span>
                        <span>&nbsp;</span>
                        <span class="wow fadeInUp" data-wow-delay="0.60s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">m</span>
                        <span class="wow fadeInUp" data-wow-delay="0.65s" style="visibility: visible; animation-delay: 0.65s; animation-name: fadeInUp;">a</span>
                        <span class="wow fadeInUp" data-wow-delay="0.70s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.75s" style="visibility: visible; animation-delay: 0.75s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.80s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">i</span>
                        <span class="wow fadeInUp" data-wow-delay="0.85s" style="visibility: visible; animation-delay: 0.85s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.90s" style="visibility: visible; animation-delay: 0.9s; animation-name: fadeInUp;">d</span>
                    </span>

                    <div class="couple-name wow fadeInUp" data-wow-delay="2s" style="visibility: visible; animation-delay: 2s; animation-name: fadeInUp;">
                        <h1>Tushar &amp; Riti</h1>
                    </div>
                    <span class="date wow fadeInUp" data-wow-delay="3s" style="visibility: visible; animation-delay: 3s; animation-name: fadeInUp;">05.02.2018</span>
                    <span class="vector wow fadeInUp" data-wow-delay="3.5s" style="visibility: visible; animation-delay: 3.5s; animation-name: fadeInUp;"></span>
                </div>-->
            </div>
					</li>
					<li style="position:relative;">
					  <img src="images/banner-2.jpg" alt="">
						<div class="announcement-wrapper">
                <!--<div class="announcement">
                    <span class="married-text">
                        <span class="wow fadeInUp" data-wow-delay="0.05s" style="visibility: visible; animation-delay: 0.05s; animation-name: fadeInUp;">W</span>
                        <span class="wow fadeInUp" data-wow-delay="0.10s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.15s" style="visibility: visible; animation-delay: 0.15s; animation-name: fadeInUp;">'</span>
                        <span class="wow fadeInUp" data-wow-delay="0.20s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.25s" style="visibility: visible; animation-delay: 0.25s; animation-name: fadeInUp;">e</span>
                        <span>&nbsp;</span>
                        <span class="wow fadeInUp" data-wow-delay="0.30s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">g</span>
                        <span class="wow fadeInUp" data-wow-delay="0.35s" style="visibility: visible; animation-delay: 0.35s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.40s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">t</span>
                        <span class="wow fadeInUp" data-wow-delay="0.45s" style="visibility: visible; animation-delay: 0.45s; animation-name: fadeInUp;">i</span>
                        <span class="wow fadeInUp" data-wow-delay="0.50s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">n</span>
                        <span class="wow fadeInUp" data-wow-delay="0.55s" style="visibility: visible; animation-delay: 0.55s; animation-name: fadeInUp;">g</span>
                        <span>&nbsp;</span>
                        <span class="wow fadeInUp" data-wow-delay="0.60s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">m</span>
                        <span class="wow fadeInUp" data-wow-delay="0.65s" style="visibility: visible; animation-delay: 0.65s; animation-name: fadeInUp;">a</span>
                        <span class="wow fadeInUp" data-wow-delay="0.70s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.75s" style="visibility: visible; animation-delay: 0.75s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.80s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">i</span>
                        <span class="wow fadeInUp" data-wow-delay="0.85s" style="visibility: visible; animation-delay: 0.85s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.90s" style="visibility: visible; animation-delay: 0.9s; animation-name: fadeInUp;">d</span>
                    </span>

                    <div class="couple-name wow fadeInUp" data-wow-delay="2s" style="visibility: visible; animation-delay: 2s; animation-name: fadeInUp;">
                        <h1>Tushar &amp; Riti</h1>
                    </div>
                    <span class="date wow fadeInUp" data-wow-delay="3s" style="visibility: visible; animation-delay: 3s; animation-name: fadeInUp;">05.02.2018</span>
                    <span class="vector wow fadeInUp" data-wow-delay="3.5s" style="visibility: visible; animation-delay: 3.5s; animation-name: fadeInUp;"></span>
                </div>-->
            </div>
					</li><li style="position:relative;">
					  <img src="images/banner-3.jpg" alt="">
						<div class="announcement-wrapper">
                <!--<div class="announcement">
                    <span class="married-text">
                        <span class="wow fadeInUp" data-wow-delay="0.05s" style="visibility: visible; animation-delay: 0.05s; animation-name: fadeInUp;">W</span>
                        <span class="wow fadeInUp" data-wow-delay="0.10s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.15s" style="visibility: visible; animation-delay: 0.15s; animation-name: fadeInUp;">'</span>
                        <span class="wow fadeInUp" data-wow-delay="0.20s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.25s" style="visibility: visible; animation-delay: 0.25s; animation-name: fadeInUp;">e</span>
                        <span>&nbsp;</span>
                        <span class="wow fadeInUp" data-wow-delay="0.30s" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">g</span>
                        <span class="wow fadeInUp" data-wow-delay="0.35s" style="visibility: visible; animation-delay: 0.35s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.40s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">t</span>
                        <span class="wow fadeInUp" data-wow-delay="0.45s" style="visibility: visible; animation-delay: 0.45s; animation-name: fadeInUp;">i</span>
                        <span class="wow fadeInUp" data-wow-delay="0.50s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;">n</span>
                        <span class="wow fadeInUp" data-wow-delay="0.55s" style="visibility: visible; animation-delay: 0.55s; animation-name: fadeInUp;">g</span>
                        <span>&nbsp;</span>
                        <span class="wow fadeInUp" data-wow-delay="0.60s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">m</span>
                        <span class="wow fadeInUp" data-wow-delay="0.65s" style="visibility: visible; animation-delay: 0.65s; animation-name: fadeInUp;">a</span>
                        <span class="wow fadeInUp" data-wow-delay="0.70s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.75s" style="visibility: visible; animation-delay: 0.75s; animation-name: fadeInUp;">r</span>
                        <span class="wow fadeInUp" data-wow-delay="0.80s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInUp;">i</span>
                        <span class="wow fadeInUp" data-wow-delay="0.85s" style="visibility: visible; animation-delay: 0.85s; animation-name: fadeInUp;">e</span>
                        <span class="wow fadeInUp" data-wow-delay="0.90s" style="visibility: visible; animation-delay: 0.9s; animation-name: fadeInUp;">d</span>
                    </span>

                    <div class="couple-name wow fadeInUp" data-wow-delay="2s" style="visibility: visible; animation-delay: 2s; animation-name: fadeInUp;">
                        <h1>Tushar &amp; Riti</h1>
                    </div>
                    <span class="date wow fadeInUp" data-wow-delay="3s" style="visibility: visible; animation-delay: 3s; animation-name: fadeInUp;">05.02.2018</span>
                    <span class="vector wow fadeInUp" data-wow-delay="3.5s" style="visibility: visible; animation-delay: 3.5s; animation-name: fadeInUp;"></span>
                </div>-->
            </div>
					</li>
				</ul>
		  </div>
	  </div>
      
	</div>
        <!-- end of hero slider -->


        <!-- start count-down -->
        <section class="count-down">
            <div class="container">
                <div class="row">
                    <div class="col col-md-4 hidden-sm hidden-xs">
                        <h2>Our Big Day</h2>
                    </div>
                    <div class="col col-md-8">
                        <div id="clock"></div>
                    </div>
                </div> 
              <!-- end of row -->
            </div> <!-- end of container -->
        </section>
        <!-- end of count-down -->
	<!--banner-->
    <section class="couple section-padding parallax-flower" data-bg-image-top="images/big-flower.png" data-bg-image-bottom="images/big-flower-bt.png" id="couple" style="background-image: url(&quot;images/big-flower.png&quot;), url(&quot;images/big-flower-bt.png&quot;); background-position: 0% -127px, 100% -127px;">
            <div class="container">
                <div class="row section-title">
                    <div class="title-box">
                        <div class="double-line double-line-top">
                            <i class="fi fa fa-heart-o"></i>
                            <i class="fi fa fa-heart-o"></i>                        </div>
                        <h2>Happy couple</h2>
                        <div class="double-line double-line-bottom"></div>
                    </div>
                </div>

                <div class="row groom">
                    <div class="col col-md-4 col-sm-5 wow fadeInLeftSlow" data-wow-duration="2s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: fadeInLeftSlow;">
                        <div class="pic">
                            <img src="images/jay.jpg" class="img img-responsive" alt="">                        </div>
                    </div>
                    <div class="col col-md-8 col-sm-7 wow fadeInLeftSlow" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: fadeInLeftSlow;">
                        <div class="details">
                            <span>The groom</span>
                            <h4>Mr. Jay</h4>
                            <!--<div class="table-responsive">
                                <table class="table">
                                    <colgroup>
                                        <col class="first-col">
                                        <col class="sec-col">
                                    </colgroup>
                                    <tbody><tr>
                                        <td>Name</td>
                                        <td>Tushar Prajapati</td>
                                    </tr>
                                    <tr>
                                        <td>Father</td>
                                        <td>Rameshbhai K. Prajapati</td>
                                    </tr>
                                    <tr>
                                        <td>Mother</td>
                                        <td>Bhavnaben R. Prajapati</td>
                                    </tr>
                                    <tr>
                                        <td>Date of birth</td>
                                        <td>21/03/1989</td>
                                    </tr>
                                    <tr>
                                        <td>Mobile</td>
                                        <td>+91 9725464066</td>
                                    </tr>
                                </tbody></table>
                            </div>-->
                            <p  class="text-justify">Jay Bharat Vadariya was born on 21 Oct 1993 in Kaneri, Gujarat to BharatBhai Vadariya and Neetaben Vadariya.  </p>
                            <p class="text-justify">He Grew up in Kaneri.He love to Travel and explore new things. He is good businessman and also good human being. </p>
                          <ul class="social-links">
                                <li><a href="https://www.facebook.com/jay.vadariya.3?hc_ref=ARTpHbSdOxLovURFQXnCDuWpU9xuvC9Tk4EE1CcheMOKV1oCjk-SX1PTI8TAMzV7z6E&pnref=story" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                <li><a href="https://www.instagram.com/vadariya_jay/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- end of groom -->

                <div class="row bride">
                    <div class="col col-md-4 col-md-push-8 col-sm-5 col-sm-push-7 wow fadeInRightSlow" data-wow-duration="2s" data-wow-delay="0.5s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.5s; animation-name: fadeInRightSlow;">
                        <div class="pic">
                            <img src="images/jayshree.jpg" class="img img-responsive" alt="">                        </div>
                    </div>

                    <div class="col col-md-8 col-md-pull-4 col-sm-7 col-sm-pull-5">
                        <div class="details wow fadeInRightSlow" data-wow-duration="2s" style="visibility: visible; animation-duration: 2s; animation-name: fadeInRightSlow;">
                            <span>The bride</span>
                            <h4>Jayshree</h4>
                              <p class="text-justify">On 23 Aug 1994, Jayshree Bhimani was born in Dhrol. Daughter of  Late Mr.Mansukhbhai Bhimani & Mrs.Nirmalaben Bhimani. She love to Social Work.</p>
                            <p class="text-justify">She received her degree in Master of Science from the K.S.K.V. Kutch University, Bhuj.</p>
                            <p class="text-justify">Jayshree later Join Claris Lifesciences Limited in Ahmedabad.  </p>
                            <ul class="social-links">
                                <li><a href="https://www.facebook.com/jayshree.patel.3192479" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- end of bride -->
            </div> 
<!-- end of container -->
        </section>
    
    <section class="story section-padding" id="story">
            <div class="container">
                <div class="row section-title">
                    <div class="title-box">
                        <div class="double-line double-line-top">
                            <i class="fi fa fa-heart-o"></i>
                            <i class="fi fa fa-heart-o"></i>
                        </div>
                        <h2>Sweet love story</h2>
                        <div class="double-line double-line-bottom"></div>
                    </div>
                </div> <!-- end of section-title -->

                <div class="row story-box-wrapper">
                    <div class="col col-lg-8">
                        <div class="story-box">
                            <div>
                                <ul class="nav nav-tabs" role="tablist">
                                    <li role="presentation" class="active">
                                        <a href="#first-meet" aria-controls="first-meet" role="tab" data-toggle="tab" aria-expanded="true">
                                        <i class="fi fa fa-handshake-o"></i>
                                        First Meet</a>
                                    </li>
                                    <li role="presentation" class="">
                                        <a href="#first-date" aria-controls="first-date" role="tab" data-toggle="tab" aria-expanded="false">
                                        <i class="fi fa fa-calendar"></i>
                                        Meet Again</a>
                                        </li>
                                    <li role="presentation" class="">
                                        <a href="#proposal" aria-controls="proposal" role="tab" data-toggle="tab" aria-expanded="false">
                                        <i class="fi fa fa-gratipay"></i>
                                        Proposal Day</a>
                                    </li>
                                    <li role="presentation" class="">
                                        <a href="#engagement" aria-controls="engagement" role="tab" data-toggle="tab" aria-expanded="false">
                                        <i class="fi fa fa-life-ring"></i>
                                        Engagement</a>
                                    </li>
                                </ul>

                                <div class="tab-content">
                                    <div role="tabpanel" class="row tab-pane fade active in" id="first-meet">
                                        <div class="col col-lg-6 col-md-4 col-sm-5">
                                            <img src="images/first-meet.jpg" class="img img-responsive" alt="">
                                        </div>
                                        <div class="col col-lg-6 col-md-8 col-sm-7 story-details">
                                            <h3>Our first meet</h3>
                                           
                                            <p  class="text-justify">Our story began in the M.sc. 2<sup>nd</sup> Year at K.S.K.V College In Kutch. It was a beautiful day. There was a Lovely meet at a first time in a class. We got punished to share same bench for whole year. A pretty turbulent fight allowed us to get to know each other. We study together, we help each other. Throughout the year we became good friends. Whole Year we enjoy every moment of Friendship. We three Jay, Jayshree and Kishan  became Best Friends. After Completion of 3<sup>rd</sup> Year our class was changed, and then we changed our school and forgot all those days and moved on their life...</p>
                                        </div>
                                    </div>

                                    <div role="tabpanel" class="row tab-pane fade" id="first-date">
                                        <div class="col col-lg-6 col-md-4 col-sm-5">
                                            <img src="images/meet-again.jpg" class="img img-responsive" alt="">
                                        </div>
                                        <div class="col col-lg-6 col-md-8 col-sm-7 story-details">
                                            <h3>Meet Again</h3>
                                            <span class="date">14 Apr 2016</span>
                                            <p  class="text-justify"> So many years passed we are grown up. We were in Same field work area and living Same lives. We never expected that we will meet again in this beautiful world, although we lived in same area but, we never crossed each other. May be destiny decided something else for us ....after its almost 2 years we met one day again OMG!!! It was so surprising...there was yesha�s wedding. We saw each other and just shocked we don�t have words to speak...we both were so busy in our life we never thought about it, on that wedding day we got our old friends again. Then again journey of our friendship started. We talk, we fight, we share our past life but we never thought about marriage.</p>
                                        </div>                                        
                                    </div>

                                    <div role="tabpanel" class="row tab-pane fade" id="proposal">
                                        <div class="col col-lg-6 col-md-4 col-sm-5">
                                            <img src="images/propose.jpg" class="img img-responsive" alt="">
                                        </div>
                                        <div class="col col-lg-6 col-md-8 col-sm-7 story-details">
                                            <h3>Proposal day</h3>
                                            <span class="date">20 Feb 2017</span>
                                            <p  class="text-justify">Days were going so smoothly...Day by Day we get closer. Our Dreams, expectations, lifestyles are so similar. One day we thought it can�t be awesome if, friends become a life partner. We think on it for many days, one day we decided that we could be a life partner, if our parents allowed us. We share our feelings with our parents and on 20th February 2017 they allowed us and we got permission for our relation. Now we are not only friends we got name for our relation.</p>
                                        </div>                                        
                                    </div>

                                    <div role="tabpanel" class="row tab-pane fade" id="engagement">
                                        <div class="col col-lg-6 col-md-4 col-sm-5">
                                            <img src="images/engement.jpg" class="img img-responsive" alt="">
                                        </div>
                                        <div class="col col-lg-6 col-md-8 col-sm-7 story-details">
                                            <h3>Engagement</h3>
                                            <span class="date">21 jan 2018</span>
                                            <p  class="text-justify">21th jan 2018...Oh my god it was so happiest day of our life...our dream come true...finally we engaged on that day...our whole family seems so happy... Occasion was held at Hotel Eulogia Inn. Everybody was surprised by our Grand Entry. We have exchanged Rings in presence of all Relatives and friends. Each Guest was satisfied with our Arrangement. Every one blessed us for our future life. Now countdown starts for wedding.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- end of story-box -->
                    </div> <!-- end of col -->

                    <div class="col col-lg-4">
                        <div class="pic-holder">
                            <img src="images/engement.jpg" class="img img-responsive" alt="">
                            <h3>And, We�re Getting Married</h3>
                        </div>
                  </div>
                </div>

            </div> <!-- end of container -->
        </section>
    <div class="clearfix"></div>
    
    <section class="wedding-block" id="wedding">
    <div class="container">
    <div class="row">
     <div class="row section-title">
                    <div class="title-box">
                        <div class="double-line double-line-top">
                            <i class="fi fa fa-heart-o"></i>
                            <i class="fi fa fa-heart-o"></i>
                        </div>
                        <h2>Wedding</h2>
                        <div class="double-line double-line-bottom"></div>
                    </div>
                </div>
    <div class="couple-name">
                    <h1>Jay  <span class="fa fa-heart"></span> Jayshree</h1>
                    <p class="col-md-6 col-md-offset-3 col-xs-12">We would like to invite you all with full family ....</p>
                   
                  </div>
    <div class="clearfix"></div>
    <div class="col-md-12">
    <div class="col-md-4">
    <div class="ceremony-detail">
    <i class="fa fa-filter" aria-hidden="true"></i>
    <h2>Garba </h2>
<h4>18 Feb 2018 at 8:00 pm</h4>
<h5><i class="fa fa-map-marker" aria-hidden="true"></i></h5>
<p>Kishan Industries At Kaneri, Keshod.</p>
    </div>
    </div>
    
    <div class="col-md-4">
    <div class="ceremony-detail">
    <i class="fa fa-filter" aria-hidden="true"></i>
    <h2>Marriage Ceremony</h2>
<h4>19 Feb 2018 at 8:00 am</h4>
<h5><i class="fa fa-map-marker" aria-hidden="true"></i></h5>
<p>Patel Samaj Vadi, Dhrol.</p>
    </div>
    </div>
    
    <div class="col-md-4">
    <div class="ceremony-detail">
    <i class="fa fa-filter" aria-hidden="true"></i>
    <h2>Reception </h2>
<h4>16 March 2018 at 7:30 pm</h4>
<h5><i class="fa fa-map-marker" aria-hidden="true"></i></h5>
<p>Fantasy Word Near., Gandhinagar .</p>
    </div>
    </div>
    </div>
    </div>
    </div>
    </section>
    
    <section class="events gallery section-padding parallax-flower" data-bg-image-top="images/big-flower.png" data-bg-image-bottom="images/big-flower-bt.png" id="people" style="background-image: url(&quot;images/big-flower.png&quot;), url(&quot;images/big-flower-bt.png&quot;); background-position: 0% -38.9167px, 100% -38.9167px;">
            <div class="container">
                <div class="row section-title">
                    <div class="title-box">
                        <div class="double-line double-line-top">
                            <i class="fi fa fa-heart-o"></i>
                            <i class="fi fa fa-heart-o"></i>                        </div>
                        <h2>Vadariya & Bhimani Family waiting for your presence</h2>
                        <div class="double-line double-line-bottom"></div>
                    </div>
                </div> <!-- end of section-title -->

                <div class="row gallery-boxes">
                    <div class="col col-md-4 col-xs-12 wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                        <div class="box">
                            <a href="images/jay-parents.jpg" class="lightview" data-lightview-group="example">
                                <img src="images/jay-parents.jpg" class="img img-responsive" alt="">
                                <div class="details">
                                                        <div>
                                                            <h5>Jay's Parents</h5>
                                                            
                                                            <span class="icon"><i class="fa fa-search"></i></span>                                                        </div>
                                                    </div>
                            </a>                        </div>
                    </div>
                    
                    <div class="col col-md-4 col-xs-12 wow fadeIn" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
                        <div class="event-boxes">
                            <div class="left-half appeared slideOutLeft" style="left: 0px;"></div>
                            <div class="right-half appeared slideOutRight" style="right: 0px;"></div>
                            <div class="clip appeared clip-fade-out"><i class="fi fa fa-link"></i></div>
                            <div class="event-box-inner">
                                <div class="main-ceromony">
                                    <h3>Wedding ceremony</h3>
                                    <ul>
                                        <li><i class="fa fa-calendar"></i> Monday, 19 Feb 2018 (8.00 AM Onwards)</li>
                                        <li><i class="fa fa-location-arrow"></i> Patel Samaj Wadi, Dhrol.</li>
                                    </ul>
                                </div>
                                <div class="reception">
                                    <h3>Garba party</h3>
                                    <ul>
                                        <li><i class="fa fa-calendar"></i> Sunday, 18 Feb 2018 (8.00 PM Onwards)</li>
                                        <li><i class="fa fa-location-arrow"></i> Kishan Industries At Kaneri, Keshod.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col col-md-4 col-xs-12 wow fadeIn" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
                        <div class="box">
                            <a href="images/jayshree-parents.jpg" class="lightview" data-lightview-group="example">
                                <img src="images/jayshree-parents.jpg" class="img img-responsive" alt="">
                                <div class="details">
                                                        <div>
                                                            <h5>Jayshree's Parents</h5>
                                                            
                                                            <span class="icon"><i class="fa fa-search"></i></span>                                                        </div>
                                                    </div>
                            </a>                        </div>
                    </div>
                </div>
            </div> 
<!-- end of container -->
        </section>
        <div class="clearfix"></div>
    
        <!-- end of important-people -->
    
   <section class="events section-padding" id="events">
            <div class="container">
                <div class="row section-title">
                    <div class="title-box">
                        <div class="double-line double-line-top">
                            <i class="fi fa fa-heart-o"></i>
                            <i class="fi fa fa-heart-o"></i>
                        </div>
                        <h2>The wedding</h2>
                        <div class="double-line double-line-bottom"></div>
                    </div>
                </div> <!-- end of section-title -->

                <div class="row content">
                    <div class="col col-md-6">
                        <div class="event-boxes">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2190.745057062237!2d70.41244919074894!3d22.564911698001403!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39575f9a1f6c126f%3A0x69440ac1970dbda2!2sPatel+Samajwadi!5e0!3m2!1sen!2sin!4v1518415380030" width="544" height="410" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                  </div>

                    <div class="col col-md-6">
                        <div class="event-boxes"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4420.567929300194!2d70.30882903054072!3d21.30154188509432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bfd511496300749%3A0xd6f9f2a767f5ec8a!2sKishan+Industries!5e0!3m2!1sen!2sin!4v1518415426869" width="544" height="410" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                  </div>
                </div>
            </div> <!-- end of container -->
        </section>
    
    
  
		<!--footer-->
					<?php include('include/footer.php');?>
				
			
    <script src="js/jquery1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="js/jquery-plugin-collection.js"></script>
    <script src="dngview007/js/dngview/dngview.js"></script>
    <script src="js/responsiveslides.min.js"></script>
        
 <script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>
    <!-- Custom script for this template -->
    <script src="js/script.js"></script>
</body>
</html>

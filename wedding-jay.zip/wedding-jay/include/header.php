
            
        
         <header id="header">
         
            <nav class="navigation navbar navbar-default">
                <div class="container">
                    <div class="navbar-header">
                    
                        <button type="button" class="open-btn">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand logo-small" href="#"><img src="images/logo-v2.png" alt="" /></a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse navbar-right">
                        <button class="close-navbar"><i class="fa fa-close"></i></button>
                        <ul class="nav navbar-nav">
                            <li class="mobile-menu-logo">Jay <i class="fa fa-heart"></i> Jayshree</li>
                            <li class="active"><a href="index.php">Home</a></li>
                            <!--<li><a href="#couple">Couple</a></li>-->
                            <li><a href="#story">Story</a></li>
                            <li><a href="#wedding">Events</a></li>
                           <!-- <li><a href="#people">People</a></li>-->
                            <li><a href="#events">Location</a></li>
                            <li><a href="gallery.php">Photo Gallery</a></li>
                           
                        </ul>
                    </div><!-- end of nav-collapse -->
                   
                </div><!-- end of container -->
            </nav>

            <div class="logo-bottom-shape-wrapper container">
                <div class="logo-bottom-shape wow fadeInDown" data-wow-delay="4s">
                    <span>J <i class="fa fa-heart"></i> J</span>
                </div>
            </div>
        </header>
         
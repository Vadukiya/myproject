<footer class="section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-8 col-xs-10 col-md-offset-2 col-xs-offset-1">
                        <div class="box">
                            <!-- frame -->
                            <div class="left-top-border"></div> 
                            <div class="right-top-border"></div> 
                            <div class="bottom-right-border"></div> 
                            <div class="bottom-left-border"></div> 
                            <!-- frame -->

                            <div class="love-birds wow fadeInSlow" style="visibility: visible; animation-name: fadeInSlow;"><i class="fi fa fa-heart"></i></div>
                            <h2 class="wow fadeInSlow" style="visibility: visible; animation-name: fadeInSlow;">We are getting married</h2>
                            <p class="wow fadeInSlow" style="visibility: visible; animation-name: fadeInSlow;">Jay &amp; Jayshree</p>
                            <span class="wow fadeInSlow" style="visibility: visible; animation-name: fadeInSlow;">19 Feb 2018</span>
                        </div>
                        <p class="copyright">Website Designed by <a href="https://www.facebook.com/profile.php?id=100008469196654" target="_blank" style="color:#fff;"><strong style="color:#aa9a45;">Kishan Trambadiya. </strong></a></p>
                  </div>
                </div>
            </div>
        </footer>